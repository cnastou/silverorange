<?php

namespace silverorange\DevTest\Model;

class Author
{
    public string $id;
    public string $full_name;
    public string $created_at;
    public string $modified_at;
}
