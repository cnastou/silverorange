<?php

namespace silverorange\DevTest;

class Config
{
    public string $dsn = 'pgsql:host=localhost;port=5532;dbname=silverorange;user=silverorange;password=silverorange';
}
